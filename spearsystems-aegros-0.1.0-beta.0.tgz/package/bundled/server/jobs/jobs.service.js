"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var JobsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobsService = void 0;
const common_1 = require("@nestjs/common");
const aegros_core_1 = require("@spearsystems/aegros-core");
const fs_artifact_writer_1 = require("../artifacts/fs-artifact-writer");
const audit_service_1 = require("../audit/audit.service");
const docker_scanner_service_1 = require("../docker/docker-scanner.service");
const prisma_service_1 = require("../prisma/prisma.service");
const webhooks_service_1 = require("../webhooks/webhooks.service");
let JobsService = JobsService_1 = class JobsService {
    prisma;
    docker;
    audit;
    webhooks;
    ai;
    log = new common_1.Logger(JobsService_1.name);
    constructor(prisma, docker, audit, webhooks, ai) {
        this.prisma = prisma;
        this.docker = docker;
        this.audit = audit;
        this.webhooks = webhooks;
        this.ai = ai;
    }
    async onModuleInit() {
        const n = await this.prisma.job.updateMany({
            where: { status: 'running' },
            data: { status: 'queued', errorMessage: 'Recovered after restart — re-run pending' },
        });
        if (n.count > 0) {
            this.log.warn(`Reset ${n.count} running job(s) to queued for recovery`);
        }
        const recovered = await this.prisma.job.findMany({
            where: { status: 'queued', errorMessage: { contains: 'Recovered after restart' } },
            select: { id: true },
        });
        for (const j of recovered) {
            void this.runJob(j.id);
        }
    }
    async create(domains, policyRaw, ackAuthorized, apiKeyId) {
        if (process.env.AEGROS_ENFORCE_ACK?.trim() === 'true' && !ackAuthorized) {
            throw new common_1.BadRequestException('ackAuthorized must be true when AEGROS_ENFORCE_ACK=true');
        }
        const scope = (0, aegros_core_1.normalizeDomainsToScope)(domains);
        if (scope.length === 0) {
            throw new common_1.BadRequestException('No valid domains after normalization');
        }
        const policy = (0, aegros_core_1.parseScanPolicy)(policyRaw);
        const row = await this.prisma.job.create({
            data: {
                status: 'queued',
                domainsJson: JSON.stringify(scope),
                policy,
            },
        });
        await this.audit.log({
            action: 'job.create',
            resource: row.id,
            meta: { domains: scope, policy },
            jobId: row.id,
            apiKeyId: apiKeyId ?? null,
        });
        void this.runJob(row.id);
        return this.toRecord(row);
    }
    async get(id) {
        const row = await this.prisma.job.findUnique({ where: { id } });
        if (!row) {
            throw new common_1.NotFoundException(`Job ${id} not found`);
        }
        return this.toRecord(row);
    }
    async list() {
        const rows = await this.prisma.job.findMany({ orderBy: { createdAt: 'desc' } });
        return rows.map((r) => this.toRecord(r));
    }
    toRecord(row) {
        const domains = JSON.parse(row.domainsJson);
        let report = null;
        if (row.reportJson) {
            try {
                report = JSON.parse(row.reportJson);
            }
            catch {
                report = null;
            }
        }
        let stages = null;
        if (row.stagesJson) {
            try {
                stages = JSON.parse(row.stagesJson);
            }
            catch {
                stages = null;
            }
        }
        return {
            id: row.id,
            status: row.status,
            domains,
            policy: row.policy,
            report,
            createdAt: row.createdAt.toISOString(),
            updatedAt: row.updatedAt.toISOString(),
            currentStage: row.currentStage,
            stages,
            errorMessage: row.errorMessage,
        };
    }
    async persistStages(id, stages, current) {
        await this.prisma.job.update({
            where: { id },
            data: {
                stagesJson: JSON.stringify(stages),
                currentStage: current ?? null,
                updatedAt: new Date(),
            },
        });
    }
    async runJob(id) {
        const stages = {};
        try {
            await this.prisma.job.update({
                where: { id },
                data: { status: 'running', errorMessage: null },
            });
            const row = await this.prisma.job.findUniqueOrThrow({ where: { id } });
            const domains = JSON.parse(row.domainsJson);
            const policy = (0, aegros_core_1.parseScanPolicy)(row.policy);
            const writer = (0, fs_artifact_writer_1.createFsArtifactWriter)((0, fs_artifact_writer_1.resolveArtifactsDir)(), id);
            const useAi = Boolean(process.env.AEGROS_AI_PROVIDER?.trim());
            const report = await (0, aegros_core_1.executePipeline)({
                jobId: id,
                domains,
                policy,
                writer,
                fetchImpl: fetch,
                budgets: {
                    maxHttpRequests: Number(process.env.AEGROS_MAX_HTTP ?? 40),
                    maxSubdomains: Number(process.env.AEGROS_MAX_SUBDOMAINS ?? 80),
                    wallMs: Number(process.env.AEGROS_WALL_MS ?? 120_000),
                },
                linuxScanner: policy === 'aggressive' && this.docker.isConfigured()
                    ? (req) => this.docker.run(req)
                    : undefined,
                ai: useAi ? this.ai : undefined,
                onStage: (stage, status, detail) => {
                    const now = new Date().toISOString();
                    if (status === 'started') {
                        stages[stage] = { status: 'running', startedAt: now };
                    }
                    else if (status === 'finished') {
                        stages[stage] = {
                            status: 'succeeded',
                            startedAt: stages[stage]?.startedAt,
                            finishedAt: now,
                        };
                    }
                    else {
                        stages[stage] = {
                            status: 'failed',
                            startedAt: stages[stage]?.startedAt,
                            finishedAt: now,
                            detail,
                        };
                    }
                    void this.persistStages(id, stages, stage);
                },
            });
            await this.prisma.job.update({
                where: { id },
                data: {
                    status: 'succeeded',
                    reportJson: JSON.stringify(report),
                    stagesJson: JSON.stringify(stages),
                    currentStage: 'report_synthesis',
                    errorMessage: null,
                },
            });
            await this.audit.log({ action: 'job.succeeded', resource: id, jobId: id });
            await this.webhooks.notifyJobCompleted(id, report);
        }
        catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            this.log.error(`Job ${id} failed: ${msg}`);
            await this.prisma.job.update({
                where: { id },
                data: {
                    status: 'failed',
                    errorMessage: msg,
                    stagesJson: JSON.stringify(stages),
                },
            });
            await this.audit.log({ action: 'job.failed', resource: id, meta: { error: msg }, jobId: id });
        }
    }
};
exports.JobsService = JobsService;
exports.JobsService = JobsService = JobsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(4, (0, common_1.Inject)('AI_SERVICE')),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        docker_scanner_service_1.DockerScannerService,
        audit_service_1.AuditService,
        webhooks_service_1.WebhooksService, Object])
], JobsService);
//# sourceMappingURL=jobs.service.js.map