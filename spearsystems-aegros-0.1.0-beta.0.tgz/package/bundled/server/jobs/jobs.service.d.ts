import { OnModuleInit } from '@nestjs/common';
import { type JobStatus, type ReportArtifactV2, type StageStateMap } from '@spearsystems/aegros-core';
import type { AiService } from '@spearsystems/aegros-core';
import { AuditService } from '../audit/audit.service';
import { DockerScannerService } from '../docker/docker-scanner.service';
import { PrismaService } from '../prisma/prisma.service';
import { WebhooksService } from '../webhooks/webhooks.service';
export interface JobRecord {
    readonly id: string;
    status: JobStatus;
    readonly domains: readonly string[];
    readonly policy: string;
    report: ReportArtifactV2 | null;
    readonly createdAt: string;
    updatedAt: string;
    readonly currentStage: string | null;
    readonly stages: StageStateMap | null;
    readonly errorMessage: string | null;
}
export declare class JobsService implements OnModuleInit {
    private readonly prisma;
    private readonly docker;
    private readonly audit;
    private readonly webhooks;
    private readonly ai;
    private readonly log;
    constructor(prisma: PrismaService, docker: DockerScannerService, audit: AuditService, webhooks: WebhooksService, ai: AiService);
    onModuleInit(): Promise<void>;
    create(domains: string[], policyRaw?: string, ackAuthorized?: boolean, apiKeyId?: string | null): Promise<JobRecord>;
    get(id: string): Promise<JobRecord>;
    list(): Promise<JobRecord[]>;
    private toRecord;
    private persistStages;
    private runJob;
}
//# sourceMappingURL=jobs.service.d.ts.map