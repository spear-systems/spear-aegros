export declare class CreateJobDto {
    domains: string[];
    policy?: 'passive' | 'standard' | 'aggressive';
    ackAuthorized?: boolean;
}
//# sourceMappingURL=create-job.dto.d.ts.map