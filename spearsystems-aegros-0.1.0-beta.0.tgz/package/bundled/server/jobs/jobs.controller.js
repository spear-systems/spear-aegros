"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JobsController = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const sarif_1 = require("../integrations/sarif");
const create_job_dto_1 = require("./dto/create-job.dto");
const jobs_service_1 = require("./jobs.service");
let JobsController = class JobsController {
    jobs;
    constructor(jobs) {
        this.jobs = jobs;
    }
    create(body, req) {
        return this.jobs.create(body.domains, body.policy, body.ackAuthorized, req.aegrosApiKey?.id ?? null);
    }
    list() {
        return this.jobs.list();
    }
    get(id) {
        return this.jobs.get(id);
    }
    async sarif(id, res) {
        const job = await this.jobs.get(id);
        if (!job.report) {
            throw new common_1.NotFoundException('Report not available yet');
        }
        res.setHeader('Content-Type', 'application/sarif+json; charset=utf-8');
        return (0, sarif_1.reportToSarif)(job.report);
    }
    events(id) {
        return (0, rxjs_1.timer)(0, 1500).pipe((0, rxjs_1.switchMap)(() => (0, rxjs_1.from)(this.jobs.get(id))), (0, rxjs_1.map)((job) => {
            const data = JSON.stringify({
                id: job.id,
                status: job.status,
                currentStage: job.currentStage,
                stages: job.stages,
                errorMessage: job.errorMessage,
            });
            return { data };
        }), (0, rxjs_1.takeWhile)((evt) => {
            const raw = typeof evt.data === 'string' ? evt.data : JSON.stringify(evt.data);
            const j = JSON.parse(raw);
            return j.status === 'queued' || j.status === 'running';
        }, true));
    }
};
exports.JobsController = JobsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_job_dto_1.CreateJobDto, Object]),
    __metadata("design:returntype", void 0)
], JobsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], JobsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], JobsController.prototype, "get", null);
__decorate([
    (0, common_1.Get)(':id/sarif'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], JobsController.prototype, "sarif", null);
__decorate([
    (0, common_1.Sse)(':id/events'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Function)
], JobsController.prototype, "events", null);
exports.JobsController = JobsController = __decorate([
    (0, common_1.Controller)('v1/jobs'),
    __metadata("design:paramtypes", [jobs_service_1.JobsService])
], JobsController);
//# sourceMappingURL=jobs.controller.js.map