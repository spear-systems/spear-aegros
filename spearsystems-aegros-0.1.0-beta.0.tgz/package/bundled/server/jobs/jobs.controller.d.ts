import { MessageEvent } from '@nestjs/common';
import type { Request, Response } from 'express';
import type { Observable } from 'rxjs';
import { CreateJobDto } from './dto/create-job.dto';
import { JobsService } from './jobs.service';
type ReqWithKey = Request & {
    aegrosApiKey?: {
        id: string;
        role: string;
    };
};
export declare class JobsController {
    private readonly jobs;
    constructor(jobs: JobsService);
    create(body: CreateJobDto, req: ReqWithKey): Promise<import("./jobs.service").JobRecord>;
    list(): Promise<import("./jobs.service").JobRecord[]>;
    get(id: string): Promise<import("./jobs.service").JobRecord>;
    sarif(id: string, res: Response): Promise<Record<string, unknown>>;
    events(id: string): Observable<MessageEvent>;
}
export {};
//# sourceMappingURL=jobs.controller.d.ts.map