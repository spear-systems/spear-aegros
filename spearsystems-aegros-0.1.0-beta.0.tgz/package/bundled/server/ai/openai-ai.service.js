"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OpenAiAiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAiAiService = void 0;
const common_1 = require("@nestjs/common");
const redact_1 = require("./redact");
let OpenAiAiService = OpenAiAiService_1 = class OpenAiAiService {
    log = new common_1.Logger(OpenAiAiService_1.name);
    async complete(request) {
        const key = process.env.OPENAI_API_KEY?.trim();
        if (!key) {
            this.log.warn('OPENAI_API_KEY not set');
            return { text: '', finishReason: 'missing_key' };
        }
        const model = request.model ?? process.env.AEGROS_OPENAI_MODEL?.trim() ?? 'gpt-4o-mini';
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${key}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model,
                temperature: request.temperature ?? 0.2,
                max_tokens: request.maxOutputTokens ?? 800,
                messages: request.messages.map((m) => ({
                    role: m.role,
                    content: (0, redact_1.redactForAi)(m.content),
                })),
            }),
            signal: AbortSignal.timeout(120_000),
        });
        if (!res.ok) {
            const t = await res.text();
            this.log.warn(`OpenAI HTTP ${res.status}: ${t}`);
            return { text: '', finishReason: `error:${res.status}` };
        }
        const body = (await res.json());
        const text = body.choices?.[0]?.message?.content ?? '';
        return { text, finishReason: body.choices?.[0]?.finish_reason };
    }
};
exports.OpenAiAiService = OpenAiAiService;
exports.OpenAiAiService = OpenAiAiService = OpenAiAiService_1 = __decorate([
    (0, common_1.Injectable)()
], OpenAiAiService);
//# sourceMappingURL=openai-ai.service.js.map