"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AI_SERVICE = void 0;
const gemini_ai_service_1 = require("./gemini-ai.service");
const noop_ai_service_1 = require("./noop-ai.service");
const ollama_ai_service_1 = require("./ollama-ai.service");
const openai_ai_service_1 = require("./openai-ai.service");
exports.AI_SERVICE = {
    provide: 'AI_SERVICE',
    useFactory: () => {
        const p = process.env.AEGROS_AI_PROVIDER?.trim().toLowerCase();
        if (p === 'ollama')
            return new ollama_ai_service_1.OllamaAiService();
        if (p === 'openai')
            return new openai_ai_service_1.OpenAiAiService();
        if (p === 'gemini')
            return new gemini_ai_service_1.GeminiAiService();
        return new noop_ai_service_1.NoopAiService();
    },
};
//# sourceMappingURL=ai.factory.js.map