import type { AiCompleteRequest, AiCompleteResult, AiService } from '@spearsystems/aegros-core';
export declare class NoopAiService implements AiService {
    complete(request: AiCompleteRequest): Promise<AiCompleteResult>;
}
//# sourceMappingURL=noop-ai.service.d.ts.map