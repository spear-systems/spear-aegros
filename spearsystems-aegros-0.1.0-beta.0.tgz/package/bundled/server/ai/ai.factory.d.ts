import type { Provider } from '@nestjs/common';
export declare const AI_SERVICE: Provider;
//# sourceMappingURL=ai.factory.d.ts.map