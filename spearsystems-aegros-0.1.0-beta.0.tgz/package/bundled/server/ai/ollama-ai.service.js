"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var OllamaAiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OllamaAiService = void 0;
const common_1 = require("@nestjs/common");
const redact_1 = require("./redact");
let OllamaAiService = OllamaAiService_1 = class OllamaAiService {
    log = new common_1.Logger(OllamaAiService_1.name);
    async complete(request) {
        const base = process.env.AEGROS_OLLAMA_URL?.trim() || 'http://127.0.0.1:11434';
        const model = request.model ?? process.env.AEGROS_OLLAMA_MODEL?.trim() ?? 'qwen2.5:3b';
        const url = `${base.replace(/\/$/, '')}/api/chat`;
        const messages = request.messages.map((m) => ({
            role: m.role,
            content: (0, redact_1.redactForAi)(m.content),
        }));
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model,
                stream: false,
                options: { temperature: request.temperature ?? 0.2 },
                messages,
            }),
            signal: AbortSignal.timeout(120_000),
        });
        if (!res.ok) {
            const t = await res.text();
            this.log.warn(`Ollama HTTP ${res.status}: ${t}`);
            return { text: '', finishReason: `error:${res.status}` };
        }
        const body = (await res.json());
        const text = body.message?.content ?? '';
        return { text, finishReason: 'stop' };
    }
};
exports.OllamaAiService = OllamaAiService;
exports.OllamaAiService = OllamaAiService = OllamaAiService_1 = __decorate([
    (0, common_1.Injectable)()
], OllamaAiService);
//# sourceMappingURL=ollama-ai.service.js.map