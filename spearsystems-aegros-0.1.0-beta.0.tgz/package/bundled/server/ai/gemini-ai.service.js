"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var GeminiAiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GeminiAiService = void 0;
const common_1 = require("@nestjs/common");
const redact_1 = require("./redact");
let GeminiAiService = GeminiAiService_1 = class GeminiAiService {
    log = new common_1.Logger(GeminiAiService_1.name);
    async complete(request) {
        const key = process.env.GEMINI_API_KEY?.trim();
        if (!key) {
            this.log.warn('GEMINI_API_KEY not set');
            return { text: '', finishReason: 'missing_key' };
        }
        const model = request.model ?? process.env.AEGROS_GEMINI_MODEL?.trim() ?? 'gemini-2.0-flash';
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
        const parts = request.messages.map((m) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: `${m.role}: ${(0, redact_1.redactForAi)(m.content)}` }],
        }));
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents: parts }),
            signal: AbortSignal.timeout(120_000),
        });
        if (!res.ok) {
            const t = await res.text();
            this.log.warn(`Gemini HTTP ${res.status}: ${t}`);
            return { text: '', finishReason: `error:${res.status}` };
        }
        const body = (await res.json());
        const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
        return { text, finishReason: 'stop' };
    }
};
exports.GeminiAiService = GeminiAiService;
exports.GeminiAiService = GeminiAiService = GeminiAiService_1 = __decorate([
    (0, common_1.Injectable)()
], GeminiAiService);
//# sourceMappingURL=gemini-ai.service.js.map