import type { AiCompleteRequest, AiCompleteResult, AiService } from '@spearsystems/aegros-core';
export declare class OpenAiAiService implements AiService {
    private readonly log;
    complete(request: AiCompleteRequest): Promise<AiCompleteResult>;
}
//# sourceMappingURL=openai-ai.service.d.ts.map