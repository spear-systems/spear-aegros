import type { AiCompleteRequest, AiCompleteResult, AiService } from '@spearsystems/aegros-core';
export declare class GeminiAiService implements AiService {
    private readonly log;
    complete(request: AiCompleteRequest): Promise<AiCompleteResult>;
}
//# sourceMappingURL=gemini-ai.service.d.ts.map