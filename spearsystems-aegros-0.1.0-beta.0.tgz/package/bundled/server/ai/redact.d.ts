export declare function redactForAi(text: string): string;
//# sourceMappingURL=redact.d.ts.map