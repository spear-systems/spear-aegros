import type { AiCompleteRequest, AiCompleteResult, AiService } from '@spearsystems/aegros-core';
export declare class OllamaAiService implements AiService {
    private readonly log;
    complete(request: AiCompleteRequest): Promise<AiCompleteResult>;
}
//# sourceMappingURL=ollama-ai.service.d.ts.map