import { AppService } from './app.service';
export declare class AppController {
    private readonly appService;
    constructor(appService: AppService);
    getHealth(): Promise<{
        status: string;
        database: "error" | "ok";
        coreVersion: string;
        aiProvider: string;
    }>;
}
//# sourceMappingURL=app.controller.d.ts.map