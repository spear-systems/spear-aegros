import type { ReportArtifactV2 } from '@spearsystems/aegros-core';
export declare function reportToSarif(report: ReportArtifactV2): Record<string, unknown>;
//# sourceMappingURL=sarif.d.ts.map