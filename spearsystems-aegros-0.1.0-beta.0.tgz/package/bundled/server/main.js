"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const helmet_1 = __importDefault(require("helmet"));
const app_module_1 = require("./app.module");
function parseCorsOrigin() {
    const raw = process.env.CORS_ORIGIN?.trim();
    if (!raw || raw === '*') {
        return true;
    }
    return raw
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
}
async function bootstrap() {
    const logger = new common_1.Logger('Bootstrap');
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        bufferLogs: true,
    });
    app.use((0, helmet_1.default)({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
    const corsRaw = process.env.CORS_ORIGIN?.trim();
    if (process.env.NODE_ENV === 'production' && (!corsRaw || corsRaw === '*')) {
        logger.warn('CORS_ORIGIN is unset or * in production — set explicit origins (comma-separated) before exposing this host to the internet.');
    }
    app.enableCors({
        origin: parseCorsOrigin(),
        credentials: true,
    });
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
        transformOptions: { enableImplicitConversion: true },
    }));
    app.setGlobalPrefix('api');
    const portalDist = process.env.AEGROS_PORTAL_DIST?.trim() ||
        ((0, node_fs_1.existsSync)((0, node_path_1.join)(__dirname, '..', 'portal'))
            ? (0, node_path_1.join)(__dirname, '..', 'portal')
            : (0, node_path_1.join)(__dirname, '..', '..', 'aegros-portal', 'dist'));
    app.useStaticAssets(portalDist, { prefix: '/portal/' });
    const expressApp = app.getHttpAdapter().getInstance();
    expressApp.get(/^\/portal(\/.*)?$/, (req, res, next) => {
        if (req.method !== 'GET') {
            next();
            return;
        }
        if (req.path.startsWith('/portal/assets/')) {
            next();
            return;
        }
        if (/\.\w+$/.test(req.path)) {
            next();
            return;
        }
        res.sendFile((0, node_path_1.join)(portalDist, 'index.html'));
    });
    const port = Number(process.env.PORT ?? 3000);
    const host = process.env.HOST ?? '0.0.0.0';
    await app.listen(port, host);
}
void bootstrap();
//# sourceMappingURL=main.js.map