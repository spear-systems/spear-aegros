import type { ReportArtifactV2 } from '@spearsystems/aegros-core';
import { PrismaService } from '../prisma/prisma.service';
export declare class WebhooksService {
    private readonly prisma;
    private readonly log;
    constructor(prisma: PrismaService);
    notifyJobCompleted(jobId: string, report: ReportArtifactV2): Promise<void>;
}
//# sourceMappingURL=webhooks.service.d.ts.map