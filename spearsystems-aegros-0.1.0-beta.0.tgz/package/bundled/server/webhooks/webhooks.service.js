"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var WebhooksService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhooksService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../prisma/prisma.service");
let WebhooksService = WebhooksService_1 = class WebhooksService {
    prisma;
    log = new common_1.Logger(WebhooksService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async notifyJobCompleted(jobId, report) {
        const hooks = (await this.prisma.webhookSubscription.findMany({
            where: { revokedAt: null },
        }));
        if (hooks.length === 0)
            return;
        const bodyObj = {
            event: 'job.completed',
            jobId,
            status: report.status,
            domains: report.domains,
            summary: report.summary,
            generatedAt: report.generatedAt,
        };
        const body = JSON.stringify(bodyObj);
        await Promise.all(hooks.map(async (h) => {
            const events = JSON.parse(h.eventsJson);
            if (!events.includes('job.completed'))
                return;
            const sig = (0, node_crypto_1.createHmac)('sha256', h.secret).update(body).digest('hex');
            try {
                const res = await fetch(h.url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Aegros-Signature': `sha256=${sig}`,
                        'X-Aegros-Event': 'job.completed',
                    },
                    body,
                    signal: AbortSignal.timeout(15_000),
                });
                if (!res.ok) {
                    this.log.warn(`Webhook ${h.id} HTTP ${res.status}`);
                }
            }
            catch (e) {
                this.log.warn(`Webhook ${h.id} failed: ${e instanceof Error ? e.message : String(e)}`);
            }
        }));
    }
};
exports.WebhooksService = WebhooksService;
exports.WebhooksService = WebhooksService = WebhooksService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WebhooksService);
//# sourceMappingURL=webhooks.service.js.map