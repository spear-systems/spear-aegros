import { PrismaService } from '../prisma/prisma.service';
export declare class AuditService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    log(input: {
        action: string;
        resource: string;
        meta?: unknown;
        jobId?: string;
        apiKeyId?: string | null;
    }): Promise<void>;
}
//# sourceMappingURL=audit.service.d.ts.map