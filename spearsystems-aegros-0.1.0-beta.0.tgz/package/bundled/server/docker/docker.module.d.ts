export declare class DockerModule {
}
//# sourceMappingURL=docker.module.d.ts.map