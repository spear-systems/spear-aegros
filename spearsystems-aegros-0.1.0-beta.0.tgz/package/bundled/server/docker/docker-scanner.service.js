"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var DockerScannerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DockerScannerService = void 0;
const common_1 = require("@nestjs/common");
const node_child_process_1 = require("node:child_process");
const node_os_1 = require("node:os");
const aegros_core_1 = require("@spearsystems/aegros-core");
let DockerScannerService = DockerScannerService_1 = class DockerScannerService {
    log = new common_1.Logger(DockerScannerService_1.name);
    isConfigured() {
        return Boolean(process.env.AEGROS_SCANNER_IMAGE?.trim());
    }
    async run(req) {
        const image = process.env.AEGROS_SCANNER_IMAGE?.trim();
        if (!image) {
            return {
                protocol: aegros_core_1.SCANNER_PROTOCOL_V1,
                ok: false,
                stage: req.stage,
                error: 'AEGROS_SCANNER_IMAGE not set — skipping Linux sidecar.',
            };
        }
        if ((0, node_os_1.platform)() === 'win32' || (0, node_os_1.platform)() === 'darwin') {
            this.log.warn(`Docker sidecar on ${(0, node_os_1.platform)()}: ensure Docker Desktop is running.`);
        }
        const payload = `${JSON.stringify(req)}\n`;
        return await new Promise((resolve) => {
            const args = ['run', '--rm', '-i', '--network', 'bridge', image];
            const child = (0, node_child_process_1.spawn)('docker', args, { stdio: ['pipe', 'pipe', 'pipe'] });
            let stdout = '';
            let stderr = '';
            child.stdout?.on('data', (c) => {
                stdout += c.toString();
            });
            child.stderr?.on('data', (c) => {
                stderr += c.toString();
            });
            child.on('error', (err) => {
                resolve({
                    protocol: aegros_core_1.SCANNER_PROTOCOL_V1,
                    ok: false,
                    stage: req.stage,
                    error: `docker_spawn_failed: ${err.message}`,
                });
            });
            child.on('close', (code) => {
                if (code !== 0) {
                    resolve({
                        protocol: aegros_core_1.SCANNER_PROTOCOL_V1,
                        ok: false,
                        stage: req.stage,
                        error: stderr || `docker_exit_${code}`,
                    });
                    return;
                }
                try {
                    const line = stdout.trim().split('\n').filter(Boolean).pop() ?? '{}';
                    const parsed = JSON.parse(line);
                    resolve(parsed);
                }
                catch {
                    resolve({
                        protocol: aegros_core_1.SCANNER_PROTOCOL_V1,
                        ok: false,
                        stage: req.stage,
                        error: `invalid_sidecar_json: ${stdout.slice(0, 200)}`,
                    });
                }
            });
            child.stdin?.write(payload);
            child.stdin?.end();
        });
    }
};
exports.DockerScannerService = DockerScannerService;
exports.DockerScannerService = DockerScannerService = DockerScannerService_1 = __decorate([
    (0, common_1.Injectable)()
], DockerScannerService);
//# sourceMappingURL=docker-scanner.service.js.map