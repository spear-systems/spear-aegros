import type { LinuxScannerRequestV1, LinuxScannerResponseV1 } from '@spearsystems/aegros-core';
export declare class DockerScannerService {
    private readonly log;
    isConfigured(): boolean;
    run(req: LinuxScannerRequestV1): Promise<LinuxScannerResponseV1>;
}
//# sourceMappingURL=docker-scanner.service.d.ts.map