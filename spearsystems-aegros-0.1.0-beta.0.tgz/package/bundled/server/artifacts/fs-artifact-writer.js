"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFsArtifactWriter = createFsArtifactWriter;
exports.resolveArtifactsDir = resolveArtifactsDir;
const node_crypto_1 = require("node:crypto");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
function createFsArtifactWriter(baseDir, jobId) {
    const root = (0, node_path_1.join)(baseDir, jobId);
    return {
        async writeJson(stage, name, data) {
            const dir = (0, node_path_1.join)(root, stage);
            await (0, promises_1.mkdir)(dir, { recursive: true });
            const body = `${JSON.stringify(data, null, 2)}\n`;
            const sha256 = (0, node_crypto_1.createHash)('sha256').update(body).digest('hex');
            const relativePath = (0, node_path_1.join)(jobId, stage, name).replaceAll('\\', '/');
            const fullPath = (0, node_path_1.join)(baseDir, relativePath);
            await (0, promises_1.writeFile)(fullPath, body, 'utf8');
            return { relativePath, sha256 };
        },
    };
}
function resolveArtifactsDir() {
    const raw = process.env.AEGROS_ARTIFACTS_DIR?.trim();
    if (raw) {
        return raw;
    }
    return (0, node_path_1.join)(process.cwd(), 'data', 'artifacts');
}
//# sourceMappingURL=fs-artifact-writer.js.map