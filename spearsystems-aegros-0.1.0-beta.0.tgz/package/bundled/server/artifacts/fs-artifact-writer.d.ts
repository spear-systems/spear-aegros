import type { ArtifactWriter } from '@spearsystems/aegros-core';
export declare function createFsArtifactWriter(baseDir: string, jobId: string): ArtifactWriter;
export declare function resolveArtifactsDir(): string;
//# sourceMappingURL=fs-artifact-writer.d.ts.map