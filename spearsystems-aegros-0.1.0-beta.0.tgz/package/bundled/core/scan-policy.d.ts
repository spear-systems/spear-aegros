/** Scan aggressiveness — maps to engine behavior and legal posture hints. */
export type ScanPolicy = 'passive' | 'standard' | 'aggressive';
export declare const DEFAULT_SCAN_POLICY: ScanPolicy;
export declare function parseScanPolicy(raw: string | undefined): ScanPolicy;
//# sourceMappingURL=scan-policy.d.ts.map