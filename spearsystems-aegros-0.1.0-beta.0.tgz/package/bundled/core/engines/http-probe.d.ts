export interface HttpProbeResult {
    readonly url: string;
    readonly finalUrl: string;
    readonly status: number;
    readonly server?: string;
    readonly poweredBy?: string;
    readonly contentType?: string;
    readonly headers: Record<string, string>;
    readonly tls?: {
        protocol?: string;
        authorized?: boolean;
    };
    readonly error?: string;
}
export declare function probeHttpUrl(url: string, fetchImpl: typeof fetch, opts?: {
    maxRedirects?: number;
}): Promise<HttpProbeResult>;
//# sourceMappingURL=http-probe.d.ts.map