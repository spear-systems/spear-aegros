import type { TechSignal } from './tech-inference.js';
import type { Finding } from '../report-v2.js';
/** Lightweight, deterministic hints — not a replacement for authenticated scanning. */
export declare function correlateVulnsFromTech(signals: readonly TechSignal[]): Finding[];
//# sourceMappingURL=vuln-correlation.d.ts.map