"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlateVulnsFromTech = correlateVulnsFromTech;
/** Lightweight, deterministic hints — not a replacement for authenticated scanning. */
function correlateVulnsFromTech(signals) {
    const findings = [];
    for (const s of signals) {
        const p = s.product.toLowerCase();
        if (p.includes('nginx') && s.version) {
            findings.push({
                id: `tech-version-${s.product}-${s.version}`.replace(/\s+/g, '_'),
                title: `Technology version observed: ${s.product} ${s.version}`,
                severity: 'info',
                category: 'patch_management',
                description: 'Version fingerprinting from HTTP headers can be inaccurate behind reverse proxies. Correlate with package managers or SBOM where possible.',
                remediation: 'Review vendor security advisories for the inferred stack and plan upgrades.',
                evidence: s.evidence,
                source: 'deterministic',
            });
        }
        if (p.includes('apache') && s.version) {
            findings.push({
                id: `tech-version-${s.product}-${s.version}`.replace(/\s+/g, '_'),
                title: `Technology version observed: ${s.product} ${s.version}`,
                severity: 'info',
                category: 'patch_management',
                description: 'Header-derived version; validate with authenticated inspection.',
                evidence: s.evidence,
                source: 'deterministic',
            });
        }
    }
    return dedupeFindings(findings);
}
function dedupeFindings(f) {
    const m = new Map();
    for (const x of f)
        m.set(x.id, x);
    return [...m.values()];
}
//# sourceMappingURL=vuln-correlation.js.map