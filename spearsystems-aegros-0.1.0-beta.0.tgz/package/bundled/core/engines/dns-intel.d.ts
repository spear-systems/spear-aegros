export interface DnsIntelResult {
    readonly apex: string;
    readonly a: readonly string[];
    readonly aaaa: readonly string[];
    readonly mx: readonly {
        exchange: string;
        priority: number;
    }[];
    readonly txt: readonly string[];
    readonly ns: readonly string[];
    readonly errors: readonly string[];
}
export declare function collectDnsIntel(apex: string): Promise<DnsIntelResult>;
export declare function summarizeEmailAuthSurface(txt: readonly string[]): {
    spf: boolean;
    dmarc: boolean;
    dkimHints: readonly string[];
};
//# sourceMappingURL=dns-intel.d.ts.map