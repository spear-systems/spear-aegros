import type { ScanPolicy } from '../scan-policy.js';
export declare function expandSubdomainsHeuristic(apex: string, passiveNames: readonly string[], policy: ScanPolicy): string[];
//# sourceMappingURL=subdomain-expand.d.ts.map