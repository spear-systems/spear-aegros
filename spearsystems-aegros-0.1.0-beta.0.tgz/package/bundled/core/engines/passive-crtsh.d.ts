/** Certificate Transparency names via crt.sh (public). Rate-limit friendly — single batch per apex. */
export interface CrtShName {
    readonly name_value: string;
}
export declare function fetchCrtShSubdomains(apex: string, fetchImpl: typeof fetch): Promise<readonly string[]>;
//# sourceMappingURL=passive-crtsh.d.ts.map