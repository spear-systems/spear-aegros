import type { HttpProbeResult } from './http-probe.js';
export interface TechSignal {
    readonly product: string;
    readonly version?: string;
    readonly confidence: 'low' | 'medium' | 'high';
    readonly evidence: string;
}
export declare function inferTechnologies(probes: readonly HttpProbeResult[]): readonly TechSignal[];
//# sourceMappingURL=tech-inference.d.ts.map