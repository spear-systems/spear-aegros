"use strict";
/** Certificate Transparency names via crt.sh (public). Rate-limit friendly — single batch per apex. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchCrtShSubdomains = fetchCrtShSubdomains;
async function fetchCrtShSubdomains(apex, fetchImpl) {
    const q = `%.${apex}`;
    const url = `https://crt.sh/?q=${encodeURIComponent(q)}&output=json`;
    const res = await fetchImpl(url, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(25_000),
    });
    if (!res.ok) {
        throw new Error(`crt.sh HTTP ${res.status}`);
    }
    const rows = (await res.json());
    if (!Array.isArray(rows))
        return [];
    const names = new Set();
    for (const row of rows) {
        const raw = row.name_value?.split('\n') ?? [];
        for (const n of raw) {
            const s = n.trim().toLowerCase().replace(/^\*\./, '');
            if (s.endsWith(apex) || s === apex)
                names.add(s);
        }
    }
    return [...names].sort();
}
//# sourceMappingURL=passive-crtsh.js.map