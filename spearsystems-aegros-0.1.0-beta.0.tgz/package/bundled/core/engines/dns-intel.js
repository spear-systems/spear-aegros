"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.collectDnsIntel = collectDnsIntel;
exports.summarizeEmailAuthSurface = summarizeEmailAuthSurface;
const promises_1 = __importDefault(require("node:dns/promises"));
async function collectDnsIntel(apex) {
    const errors = [];
    const safe = async (label, fn) => {
        try {
            return await fn();
        }
        catch (e) {
            errors.push(`${label}: ${e instanceof Error ? e.message : String(e)}`);
            return undefined;
        }
    };
    const [a, aaaa, mx, txt, ns] = await Promise.all([
        safe('A', () => promises_1.default.resolve4(apex)),
        safe('AAAA', () => promises_1.default.resolve6(apex)),
        safe('MX', () => promises_1.default.resolveMx(apex)),
        safe('TXT', () => promises_1.default.resolveTxt(apex)),
        safe('NS', () => promises_1.default.resolveNs(apex)),
    ]);
    const flatTxt = (txt ?? []).map((chunks) => chunks.join(''));
    return {
        apex,
        a: a ?? [],
        aaaa: aaaa ?? [],
        mx: (mx ?? []).map((m) => ({ exchange: m.exchange, priority: m.priority })),
        txt: flatTxt,
        ns: ns ?? [],
        errors,
    };
}
function summarizeEmailAuthSurface(txt) {
    const joined = txt.join('\n').toLowerCase();
    const dkimHints = txt.filter((r) => r.toLowerCase().includes('dkim'));
    return {
        spf: joined.includes('v=spf1'),
        dmarc: txt.some((r) => r.toLowerCase().startsWith('v=dmarc1')),
        dkimHints,
    };
}
//# sourceMappingURL=dns-intel.js.map