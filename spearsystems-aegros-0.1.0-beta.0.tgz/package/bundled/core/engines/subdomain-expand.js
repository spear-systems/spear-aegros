"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expandSubdomainsHeuristic = expandSubdomainsHeuristic;
const COMMON = [
    'www',
    'mail',
    'api',
    'dev',
    'staging',
    'stage',
    'test',
    'vpn',
    'cdn',
    'app',
    'portal',
];
function expandSubdomainsHeuristic(apex, passiveNames, policy) {
    const set = new Set([apex, ...passiveNames.map((s) => s.toLowerCase())]);
    if (policy === 'standard' || policy === 'aggressive') {
        for (const p of COMMON) {
            set.add(`${p}.${apex}`);
        }
    }
    return [...set].sort();
}
//# sourceMappingURL=subdomain-expand.js.map