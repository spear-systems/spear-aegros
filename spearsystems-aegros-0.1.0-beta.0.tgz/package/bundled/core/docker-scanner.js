"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCANNER_PROTOCOL_V1 = void 0;
/** Contract for optional Linux scanner sidecar (stdin/stdout JSON lines). */
exports.SCANNER_PROTOCOL_V1 = 'aegros.scanner.v1';
//# sourceMappingURL=docker-scanner.js.map