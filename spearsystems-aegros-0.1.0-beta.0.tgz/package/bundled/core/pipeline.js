"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PIPELINE_ORDER = void 0;
exports.PIPELINE_ORDER = [
    'ingest',
    'passive_intel',
    'dns',
    'subdomains',
    'http_probe',
    'tech_inference',
    'vuln_correlation',
    'report_synthesis',
];
//# sourceMappingURL=pipeline.js.map