"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executePipeline = executePipeline;
const node_crypto_1 = require("node:crypto");
const docker_scanner_js_1 = require("./docker-scanner.js");
const dns_intel_js_1 = require("./engines/dns-intel.js");
const passive_crtsh_js_1 = require("./engines/passive-crtsh.js");
const http_probe_js_1 = require("./engines/http-probe.js");
const tech_inference_js_1 = require("./engines/tech-inference.js");
const subdomain_expand_js_1 = require("./engines/subdomain-expand.js");
const vuln_correlation_js_1 = require("./engines/vuln-correlation.js");
const pipeline_js_1 = require("./pipeline.js");
const report_v2_js_1 = require("./report-v2.js");
function deadlineFrom(budgets) {
    return Date.now() + budgets.wallMs;
}
function timedOut(deadline) {
    return Date.now() > deadline;
}
async function executePipeline(ctx) {
    const deadline = deadlineFrom(ctx.budgets);
    const stages = {};
    const evidence = [];
    const assets = [];
    const findings = [];
    let httpUsed = 0;
    let synthesized;
    const mark = (s, rec) => {
        stages[s] = rec;
        ctx.onStage?.(s, rec.status === 'running' ? 'started' : rec.status === 'failed' ? 'failed' : 'finished', rec.detail);
    };
    const runStage = async (stage, fn) => {
        if (timedOut(deadline))
            throw new Error('pipeline_budget_wall_ms_exceeded');
        mark(stage, { status: 'running', startedAt: new Date().toISOString() });
        try {
            const out = await fn();
            mark(stage, {
                status: 'succeeded',
                startedAt: stages[stage]?.startedAt,
                finishedAt: new Date().toISOString(),
            });
            return out;
        }
        catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            mark(stage, {
                status: 'failed',
                startedAt: stages[stage]?.startedAt,
                finishedAt: new Date().toISOString(),
                detail: msg,
            });
            throw e;
        }
    };
    const recordArtifact = async (stage, name, data) => {
        const w = await ctx.writer.writeJson(stage, name, data);
        evidence.push({ stage, relativePath: w.relativePath, sha256: w.sha256 });
    };
    for (const stage of pipeline_js_1.PIPELINE_ORDER) {
        if (timedOut(deadline))
            break;
        switch (stage) {
            case 'ingest': {
                await runStage(stage, async () => {
                    await recordArtifact(stage, 'scope.json', { domains: ctx.domains, policy: ctx.policy });
                    for (const d of ctx.domains) {
                        assets.push({ host: d, type: 'domain', notes: 'In-scope apex' });
                    }
                });
                break;
            }
            case 'passive_intel': {
                await runStage(stage, async () => {
                    const byDomain = {};
                    for (const d of ctx.domains) {
                        try {
                            byDomain[d] = [...(await (0, passive_crtsh_js_1.fetchCrtShSubdomains)(d, ctx.fetchImpl))];
                        }
                        catch {
                            byDomain[d] = [];
                        }
                    }
                    await recordArtifact(stage, 'crtsh.json', byDomain);
                });
                break;
            }
            case 'dns': {
                await runStage(stage, async () => {
                    const dnsMap = {};
                    for (const d of ctx.domains) {
                        const intel = await (0, dns_intel_js_1.collectDnsIntel)(d);
                        const email = (0, dns_intel_js_1.summarizeEmailAuthSurface)(intel.txt);
                        dnsMap[d] = { ...intel, emailAuth: email };
                        if (!email.spf) {
                            findings.push({
                                id: (0, node_crypto_1.randomUUID)(),
                                title: `Missing SPF record for ${d}`,
                                severity: 'low',
                                category: 'email_auth',
                                description: 'No TXT record starting with v=spf1 observed.',
                                remediation: 'Publish SPF aligned with your sending infrastructure.',
                                source: 'deterministic',
                            });
                        }
                        if (!email.dmarc) {
                            findings.push({
                                id: (0, node_crypto_1.randomUUID)(),
                                title: `Missing DMARC record for ${d}`,
                                severity: 'medium',
                                category: 'email_auth',
                                description: 'No DMARC policy detected at default DNS labels.',
                                remediation: 'Publish DMARC (_dmarc) with p=none→quarantine→reject rollout.',
                                source: 'deterministic',
                            });
                        }
                    }
                    await recordArtifact(stage, 'dns.json', dnsMap);
                });
                break;
            }
            case 'subdomains': {
                await runStage(stage, async () => {
                    const passive = {};
                    for (const d of ctx.domains) {
                        try {
                            passive[d] = [...(await (0, passive_crtsh_js_1.fetchCrtShSubdomains)(d, ctx.fetchImpl))];
                        }
                        catch {
                            passive[d] = [];
                        }
                    }
                    const expanded = {};
                    for (const d of ctx.domains) {
                        expanded[d] = (0, subdomain_expand_js_1.expandSubdomainsHeuristic)(d, passive[d] ?? [], ctx.policy).slice(0, ctx.budgets.maxSubdomains);
                        for (const h of expanded[d]) {
                            if (h !== d)
                                assets.push({
                                    host: h,
                                    type: 'subdomain',
                                    notes: 'Discovered or heuristic candidate',
                                });
                        }
                    }
                    await recordArtifact(stage, 'subdomains.json', expanded);
                    if (ctx.policy === 'aggressive' && ctx.linuxScanner) {
                        const req = {
                            protocol: docker_scanner_js_1.SCANNER_PROTOCOL_V1,
                            stage: 'subdomains',
                            jobId: ctx.jobId,
                            payload: { expanded, policy: ctx.policy },
                        };
                        const res = await ctx.linuxScanner(req);
                        await recordArtifact(stage, 'linux_sidecar.json', res);
                        if (!res.ok && res.error) {
                            findings.push({
                                id: (0, node_crypto_1.randomUUID)(),
                                title: 'Linux scanner sidecar reported an error',
                                severity: 'info',
                                category: 'scanner',
                                description: res.error,
                                source: 'deterministic',
                            });
                        }
                    }
                });
                break;
            }
            case 'http_probe': {
                await runStage(stage, async () => {
                    const passive = {};
                    for (const d of ctx.domains) {
                        try {
                            passive[d] = [...(await (0, passive_crtsh_js_1.fetchCrtShSubdomains)(d, ctx.fetchImpl))];
                        }
                        catch {
                            passive[d] = [];
                        }
                    }
                    const hosts = new Set();
                    for (const d of ctx.domains) {
                        for (const h of (0, subdomain_expand_js_1.expandSubdomainsHeuristic)(d, passive[d] ?? [], ctx.policy)) {
                            hosts.add(h);
                            if (hosts.size >= ctx.budgets.maxSubdomains)
                                break;
                        }
                        if (hosts.size >= ctx.budgets.maxSubdomains)
                            break;
                    }
                    const probes = [];
                    for (const host of hosts) {
                        if (httpUsed >= ctx.budgets.maxHttpRequests || timedOut(deadline))
                            break;
                        const url = `https://${host}/`;
                        httpUsed += 1;
                        const pr = await (0, http_probe_js_1.probeHttpUrl)(url, ctx.fetchImpl);
                        probes.push(pr);
                        assets.push({
                            host,
                            type: 'web_endpoint',
                            url: pr.finalUrl,
                            notes: `HTTP ${pr.status}`,
                        });
                        if (pr.status >= 500) {
                            findings.push({
                                id: (0, node_crypto_1.randomUUID)(),
                                title: `Server error on ${pr.finalUrl}`,
                                severity: 'low',
                                category: 'availability',
                                evidence: `HTTP ${pr.status}`,
                                source: 'deterministic',
                            });
                        }
                    }
                    await recordArtifact(stage, 'http.json', probes);
                });
                break;
            }
            case 'tech_inference': {
                await runStage(stage, async () => {
                    const passive = {};
                    for (const d of ctx.domains) {
                        try {
                            passive[d] = [...(await (0, passive_crtsh_js_1.fetchCrtShSubdomains)(d, ctx.fetchImpl))];
                        }
                        catch {
                            passive[d] = [];
                        }
                    }
                    const hosts = new Set();
                    for (const d of ctx.domains) {
                        for (const h of (0, subdomain_expand_js_1.expandSubdomainsHeuristic)(d, passive[d] ?? [], ctx.policy)) {
                            hosts.add(h);
                            if (hosts.size >= ctx.budgets.maxSubdomains)
                                break;
                        }
                        if (hosts.size >= ctx.budgets.maxSubdomains)
                            break;
                    }
                    const probeResults = [];
                    let used = 0;
                    for (const host of hosts) {
                        if (used >= ctx.budgets.maxHttpRequests || timedOut(deadline))
                            break;
                        used += 1;
                        probeResults.push(await (0, http_probe_js_1.probeHttpUrl)(`https://${host}/`, ctx.fetchImpl));
                    }
                    const signals = (0, tech_inference_js_1.inferTechnologies)(probeResults);
                    await recordArtifact(stage, 'tech.json', { signals, probes: probeResults });
                });
                break;
            }
            case 'vuln_correlation': {
                await runStage(stage, async () => {
                    const passive = {};
                    for (const d of ctx.domains) {
                        try {
                            passive[d] = [...(await (0, passive_crtsh_js_1.fetchCrtShSubdomains)(d, ctx.fetchImpl))];
                        }
                        catch {
                            passive[d] = [];
                        }
                    }
                    const hosts = new Set();
                    for (const d of ctx.domains) {
                        for (const h of (0, subdomain_expand_js_1.expandSubdomainsHeuristic)(d, passive[d] ?? [], ctx.policy)) {
                            hosts.add(h);
                            if (hosts.size >= ctx.budgets.maxSubdomains)
                                break;
                        }
                        if (hosts.size >= ctx.budgets.maxSubdomains)
                            break;
                    }
                    const probeResults = [];
                    let used = 0;
                    for (const host of hosts) {
                        if (used >= ctx.budgets.maxHttpRequests || timedOut(deadline))
                            break;
                        used += 1;
                        probeResults.push(await (0, http_probe_js_1.probeHttpUrl)(`https://${host}/`, ctx.fetchImpl));
                    }
                    const signals = (0, tech_inference_js_1.inferTechnologies)(probeResults);
                    const vf = (0, vuln_correlation_js_1.correlateVulnsFromTech)(signals);
                    findings.push(...vf);
                    await recordArtifact(stage, 'vuln.json', { signals, findings: vf });
                });
                break;
            }
            case 'report_synthesis': {
                await runStage(stage, async () => {
                    // findings already populated; dedupe by id
                    const uniq = new Map(findings.map((f) => [f.id, f]));
                    const allFindings = [...uniq.values()];
                    let executive;
                    if (ctx.ai) {
                        const res = await ctx.ai.complete({
                            temperature: 0.2,
                            maxOutputTokens: 800,
                            messages: [
                                {
                                    role: 'system',
                                    content: 'You are a security analyst. Write a short executive summary (max 120 words) from the structured facts only. Do not invent CVEs or products not listed.',
                                },
                                {
                                    role: 'user',
                                    content: JSON.stringify({
                                        domains: ctx.domains,
                                        findings: allFindings.map((f) => ({
                                            title: f.title,
                                            severity: f.severity,
                                            category: f.category,
                                        })),
                                    }),
                                },
                            ],
                        });
                        executive = res.text.trim();
                    }
                    synthesized = {
                        ...(0, report_v2_js_1.emptyReportV2)(ctx.jobId, 'succeeded', ctx.domains, ctx.policy),
                        summary: `Assessment completed for ${ctx.domains.join(', ')} — ${allFindings.length} finding(s).`,
                        executiveSummary: executive,
                        findings: allFindings,
                        assets,
                        evidence: [...evidence],
                        disclaimers: [
                            ...(0, report_v2_js_1.emptyReportV2)(ctx.jobId, 'succeeded', ctx.domains, ctx.policy).disclaimers,
                            'Subdomains include passive CT and light heuristics; validate ownership before testing deeper.',
                        ],
                    };
                    await recordArtifact(stage, 'report.json', synthesized);
                });
                break;
            }
            default:
                break;
        }
    }
    const uniq = new Map(findings.map((f) => [f.id, f]));
    const allFindings = [...uniq.values()];
    if (synthesized)
        return synthesized;
    return {
        ...(0, report_v2_js_1.emptyReportV2)(ctx.jobId, 'succeeded', ctx.domains, ctx.policy),
        summary: `Assessment completed for ${ctx.domains.join(', ')} — ${allFindings.length} finding(s).`,
        findings: allFindings,
        assets,
        evidence,
        disclaimers: (0, report_v2_js_1.emptyReportV2)(ctx.jobId, 'succeeded', ctx.domains, ctx.policy).disclaimers,
    };
}
//# sourceMappingURL=pipeline-runner.js.map