"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emptyReportV2 = emptyReportV2;
function emptyReportV2(jobId, status, domains, policy) {
    return {
        schema: 'spear.aegros/report@v2',
        jobId,
        status,
        generatedAt: new Date().toISOString(),
        domains,
        policy,
        summary: 'Pipeline initialized.',
        findings: [],
        assets: [],
        evidence: [],
        disclaimers: [
            'CVE and technology correlation are probabilistic; validate findings before remediation.',
            'Use only on systems you are authorized to assess.',
        ],
    };
}
//# sourceMappingURL=report-v2.js.map