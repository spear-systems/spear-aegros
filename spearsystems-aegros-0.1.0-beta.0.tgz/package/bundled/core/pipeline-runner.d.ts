import type { ArtifactWriter } from './artifact-writer.js';
import type { LinuxScannerRequestV1, LinuxScannerResponseV1 } from './docker-scanner.js';
import { type PipelineStage } from './pipeline.js';
import type { ScanPolicy } from './scan-policy.js';
import { type ReportArtifactV2 } from './report-v2.js';
export interface PipelineBudgets {
    readonly maxHttpRequests: number;
    readonly maxSubdomains: number;
    readonly wallMs: number;
}
export interface PipelineRunnerContext {
    readonly jobId: string;
    readonly domains: readonly string[];
    readonly policy: ScanPolicy;
    readonly writer: ArtifactWriter;
    readonly fetchImpl: typeof fetch;
    readonly budgets: PipelineBudgets;
    readonly linuxScanner?: (req: LinuxScannerRequestV1) => Promise<LinuxScannerResponseV1>;
    readonly ai?: {
        complete(request: {
            readonly messages: readonly {
                readonly role: string;
                readonly content: string;
            }[];
            readonly temperature?: number;
            readonly maxOutputTokens?: number;
        }): Promise<{
            readonly text: string;
        }>;
    };
    readonly onStage?: (stage: PipelineStage, status: 'started' | 'finished' | 'failed', detail?: string) => void;
}
export interface StageStateRecord {
    readonly status: 'pending' | 'running' | 'succeeded' | 'failed';
    readonly startedAt?: string;
    readonly finishedAt?: string;
    readonly detail?: string;
}
export type StageStateMap = Partial<Record<PipelineStage, StageStateRecord>>;
export declare function executePipeline(ctx: PipelineRunnerContext): Promise<ReportArtifactV2>;
//# sourceMappingURL=pipeline-runner.d.ts.map