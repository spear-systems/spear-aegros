"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emptyReportV1 = emptyReportV1;
function emptyReportV1(jobId, status, domains) {
    return {
        schema: 'spear.aegros/report@v1',
        jobId,
        status,
        generatedAt: new Date().toISOString(),
        domains,
        summary: 'Beta stub — pipeline engines not yet connected.',
    };
}
//# sourceMappingURL=reports.js.map