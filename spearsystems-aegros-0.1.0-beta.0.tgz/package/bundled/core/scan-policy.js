"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_SCAN_POLICY = void 0;
exports.parseScanPolicy = parseScanPolicy;
exports.DEFAULT_SCAN_POLICY = 'passive';
function parseScanPolicy(raw) {
    if (raw === 'standard' || raw === 'aggressive')
        return raw;
    return 'passive';
}
//# sourceMappingURL=scan-policy.js.map