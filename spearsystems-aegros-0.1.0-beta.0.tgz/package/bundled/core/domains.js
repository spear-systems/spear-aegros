"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeDomainLabel = normalizeDomainLabel;
exports.normalizeDomainsToScope = normalizeDomainsToScope;
/**
 * Normalize a single hostname: trim, lowercase ASCII, punycode for Unicode labels.
 * Does not validate TLD or perform DNS — callers enforce policy.
 */
function normalizeDomainLabel(input) {
    const trimmed = input.trim().toLowerCase();
    if (!trimmed) {
        return '';
    }
    try {
        return new URL(`http://${trimmed}`).hostname;
    }
    catch {
        return trimmed.replace(/^\.+|\.+$/g, '');
    }
}
/** Dedupe while preserving first-seen order. Filters empties after normalize. */
function normalizeDomainsToScope(domains) {
    const seen = new Set();
    const out = [];
    for (const raw of domains) {
        const n = normalizeDomainLabel(raw);
        if (!n || seen.has(n))
            continue;
        seen.add(n);
        out.push(n);
    }
    return out;
}
//# sourceMappingURL=domains.js.map