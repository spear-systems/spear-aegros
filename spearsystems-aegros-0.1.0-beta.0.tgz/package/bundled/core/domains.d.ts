/**
 * Normalize a single hostname: trim, lowercase ASCII, punycode for Unicode labels.
 * Does not validate TLD or perform DNS — callers enforce policy.
 */
export declare function normalizeDomainLabel(input: string): string;
/** Dedupe while preserving first-seen order. Filters empties after normalize. */
export declare function normalizeDomainsToScope(domains: readonly string[]): string[];
//# sourceMappingURL=domains.d.ts.map