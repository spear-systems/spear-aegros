"use strict";
/** Spear Aegros shared public API surface. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCANNER_PROTOCOL_V1 = exports.executePipeline = exports.parseScanPolicy = exports.DEFAULT_SCAN_POLICY = exports.emptyReportV2 = exports.emptyReportV1 = exports.PIPELINE_ORDER = exports.normalizeDomainsToScope = exports.normalizeDomainLabel = exports.AEGROS_CORE_VERSION = void 0;
exports.AEGROS_CORE_VERSION = '0.1.0-beta.0';
var domains_js_1 = require("./domains.js");
Object.defineProperty(exports, "normalizeDomainLabel", { enumerable: true, get: function () { return domains_js_1.normalizeDomainLabel; } });
Object.defineProperty(exports, "normalizeDomainsToScope", { enumerable: true, get: function () { return domains_js_1.normalizeDomainsToScope; } });
var pipeline_js_1 = require("./pipeline.js");
Object.defineProperty(exports, "PIPELINE_ORDER", { enumerable: true, get: function () { return pipeline_js_1.PIPELINE_ORDER; } });
var reports_js_1 = require("./reports.js");
Object.defineProperty(exports, "emptyReportV1", { enumerable: true, get: function () { return reports_js_1.emptyReportV1; } });
var report_v2_js_1 = require("./report-v2.js");
Object.defineProperty(exports, "emptyReportV2", { enumerable: true, get: function () { return report_v2_js_1.emptyReportV2; } });
var scan_policy_js_1 = require("./scan-policy.js");
Object.defineProperty(exports, "DEFAULT_SCAN_POLICY", { enumerable: true, get: function () { return scan_policy_js_1.DEFAULT_SCAN_POLICY; } });
Object.defineProperty(exports, "parseScanPolicy", { enumerable: true, get: function () { return scan_policy_js_1.parseScanPolicy; } });
var pipeline_runner_js_1 = require("./pipeline-runner.js");
Object.defineProperty(exports, "executePipeline", { enumerable: true, get: function () { return pipeline_runner_js_1.executePipeline; } });
var docker_scanner_js_1 = require("./docker-scanner.js");
Object.defineProperty(exports, "SCANNER_PROTOCOL_V1", { enumerable: true, get: function () { return docker_scanner_js_1.SCANNER_PROTOCOL_V1; } });
//# sourceMappingURL=index.js.map