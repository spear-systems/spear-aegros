export interface JobWatchProps {
    readonly jobId: string;
    readonly baseUrl: string;
    readonly apiKey?: string;
}
export declare function JobWatch({ jobId, baseUrl, apiKey }: JobWatchProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=JobWatch.d.ts.map