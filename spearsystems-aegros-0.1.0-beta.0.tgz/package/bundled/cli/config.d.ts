export interface AegrosCliConfig {
    readonly apiBaseUrl?: string;
    readonly apiKey?: string;
}
export declare function loadCliConfig(): AegrosCliConfig;
export declare function mergeBaseUrl(cli: AegrosCliConfig, flag?: string): string;
export declare function mergeApiKey(cli: AegrosCliConfig, flag?: string): string | undefined;
//# sourceMappingURL=config.d.ts.map