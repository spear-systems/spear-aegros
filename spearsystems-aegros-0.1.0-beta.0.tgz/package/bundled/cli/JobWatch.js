import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Box, Text } from 'ink';
export function JobWatch({ jobId, baseUrl, apiKey }) {
    const [line, setLine] = useState('loading…');
    const [err, setErr] = useState(null);
    useEffect(() => {
        const headers = {};
        if (apiKey)
            headers['X-API-Key'] = apiKey;
        let cancelled = false;
        const poll = { id: undefined };
        const tick = async () => {
            try {
                const url = new URL(`v1/jobs/${jobId}`, `${baseUrl}/`);
                const res = await fetch(url, { headers });
                if (!res.ok) {
                    if (!cancelled)
                        setErr(`HTTP ${res.status}`);
                    return;
                }
                const body = (await res.json());
                const stages = body.stages
                    ? Object.entries(body.stages)
                        .map(([k, v]) => `${k}:${v.status ?? '?'}`)
                        .join(' ')
                    : '';
                if (!cancelled) {
                    setLine(`status=${body.status} stage=${body.currentStage ?? '-'} ${stages}`.trim());
                    setErr(null);
                }
                if (body.status === 'succeeded' ||
                    body.status === 'failed' ||
                    body.status === 'cancelled') {
                    if (poll.id)
                        clearInterval(poll.id);
                }
            }
            catch (e) {
                if (!cancelled)
                    setErr(e instanceof Error ? e.message : String(e));
            }
        };
        void tick();
        poll.id = setInterval(() => void tick(), 1500);
        return () => {
            cancelled = true;
            if (poll.id)
                clearInterval(poll.id);
        };
    }, [jobId, baseUrl, apiKey]);
    return (_jsxs(Box, { flexDirection: "column", padding: 1, children: [_jsxs(Text, { bold: true, children: ["Job ", jobId] }), err ? _jsx(Text, { color: "red", children: err }) : _jsx(Text, { children: line }), _jsx(Text, { dimColor: true, children: "Poll mode (Ctrl+C to exit)" })] }));
}
//# sourceMappingURL=JobWatch.js.map